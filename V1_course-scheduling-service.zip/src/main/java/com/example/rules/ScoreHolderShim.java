package com.example.rules;
import org.kie.api.runtime.rule.RuleContext;
/** Minimal shim for BAMOE 9.x DRL migration. */
public class ScoreHolderShim {
    private int hard = 0;
    private int soft = 0;
    public void addHardConstraintMatch(RuleContext kctx, int match) { hard += match; }
    public void addSoftConstraintMatch(RuleContext kctx, int match) { soft += match; }
    public int getHard() { return hard; }
    public int getSoft() { return soft; }
    public void reset() { hard = 0; soft = 0; }
}